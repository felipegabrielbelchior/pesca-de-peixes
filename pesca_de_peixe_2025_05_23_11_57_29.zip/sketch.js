let linhaComprimento = 0;
let pescando = false;
let peixeX, peixeY;
let pontuacao = 0;

function setup() {
  createCanvas(600, 400);
  resetarPeixe();
}

function draw() {
  background(135, 206, 250); // Céu azul

  // Desenhar água
  fill(0, 0, 200, 100);
  noStroke();
  rect(0, height/2, width, height/2);

  // Vara de pesca
  let baseVara = width/2;
  strokeWeight(8);
  stroke(139, 69, 19); // Marrom
  line(baseVara, height, mouseX, mouseY);

  // Linha de pesca
  if(pescando) {
    linhaComprimento += 3;
  } else if(linhaComprimento > 0) {
    linhaComprimento -= 5;
  }
  linhaComprimento = constrain(linhaComprimento, 0, 200);

  let hookX = baseVara + (mouseX - baseVara) * (linhaComprimento/200);
  let hookY = height + (mouseY - height) * (linhaComprimento/200);

  // Anzol
  fill(192, 192, 192);
  ellipse(hookX, hookY, 10);

  // Peixe
  fill(255, 165, 0); // Laranja
  ellipse(peixeX, peixeY, 40, 20);
  triangle(peixeX-20, peixeY, peixeX-25, peixeY-5, peixeX-25, peixeY+5);

  // Movimento do peixe
  peixeX += random(-2, 2);
  peixeY += random(-1, 1);

  // Limites do peixe
  peixeX = constrain(peixeX, 50, width-50);
  peixeY = constrain(peixeY, 50, height/2 - 50);

  // Colisão anzol-peixe
  if(dist(hookX, hookY, peixeX, peixeY) < 25) {
    pontuacao++;
    resetarPeixe();
  }

  // Mostrar pontuação
  fill(0);
  textSize(20);
  text(`Peixes pescados: ${pontuacao}`, 20, 30);
}

function mousePressed() {
  pescando = true;
}

function mouseReleased() {
  pescando = false;
}

function resetarPeixe() {
  peixeX = random(50, width-50);
  peixeY = random(50, height/2 - 50);
}